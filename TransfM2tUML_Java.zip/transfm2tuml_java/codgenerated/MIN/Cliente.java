/**
 * Generated with MTL UML 2 Java example
 */
package MIN;

// Start of user code for imports
import java.util.*;
// End of user code

/**
 * @author MTL
 */
public class Cliente {
    /**
     * the ContaInt attribute.
     */
    private ContaInt ContaInt;
    /**
     * the CPF attribute.
     */
    private String CPF;
    /**
     * the Nome attribute.
     */
    private String Nome;
    /**
     * the ContaInt getter.
     * @return the ContaInt.
     */
    public ContaInt getContaInt() {
        return this.ContaInt;
    }

    /**
     * the ContaInt setter.
     * @param p_ContaInt the ContaInt to set.
     */
    public void setContaInt(ContaInt p_ContaInt) {
        this.ContaInt = p_ContaInt;
    }
    /**
     * the CPF getter.
     * @return the CPF.
     */
    public String getCPF() {
        return this.CPF;
    }

    /**
     * the CPF setter.
     * @param p_CPF the CPF to set.
     */
    public void setCPF(String p_CPF) {
        this.CPF = p_CPF;
    }
    /**
     * the Nome getter.
     * @return the Nome.
     */
    public String getNome() {
        return this.Nome;
    }

    /**
     * the Nome setter.
     * @param p_Nome the Nome to set.
     */
    public void setNome(String p_Nome) {
        this.Nome = p_Nome;
    }
    /**
     *     * @return
     */
    public String Cadastrar() {
        // Start of user code for operation Cadastrar
        // TODO should be implemented
        return null;
        // End of user code
    }
}
