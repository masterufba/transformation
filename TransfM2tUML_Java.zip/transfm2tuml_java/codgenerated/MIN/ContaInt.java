/**
 * Generated with MTL UML 2 Java example
 */
package MIN;

// Start of user code for imports
import java.util.*;
// End of user code

/**
 * @author MTL
 */
public class ContaInt {
    /**
     * the Cliente attribute.
     */
    private String Cliente;
    /**
     * the Senha attribute.
     */
    private Integer Senha;
    /**
     * the Login attribute.
     */
    private Integer Login;
    /**
     * the Cliente getter.
     * @return the Cliente.
     */
    public String getCliente() {
        return this.Cliente;
    }

    /**
     * the Cliente setter.
     * @param p_Cliente the Cliente to set.
     */
    public void setCliente(String p_Cliente) {
        this.Cliente = p_Cliente;
    }
    /**
     * the Senha getter.
     * @return the Senha.
     */
    public Integer getSenha() {
        return this.Senha;
    }

    /**
     * the Senha setter.
     * @param p_Senha the Senha to set.
     */
    public void setSenha(Integer p_Senha) {
        this.Senha = p_Senha;
    }
    /**
     * the Login getter.
     * @return the Login.
     */
    public Integer getLogin() {
        return this.Login;
    }

    /**
     * the Login setter.
     * @param p_Login the Login to set.
     */
    public void setLogin(Integer p_Login) {
        this.Login = p_Login;
    }
    /**
     * the dst attribute.
     */
    private ContaInt dst;
    /**
     * the src attribute.
     */
    private ContaInt src;
    /**
     * the dst attribute.
     */
    private ContaInt dst;
    /**
     * the dst attribute.
     */
    private Pagamento dst;
    /**
     * the src attribute.
     */
    private Cliente src;
    /**
     * the src attribute.
     */
    private ContaB src;
}
