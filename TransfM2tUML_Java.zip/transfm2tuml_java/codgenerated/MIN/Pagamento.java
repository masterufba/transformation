/**
 * Generated with MTL UML 2 Java example
 */
package MIN;

// Start of user code for imports
import java.util.*;
// End of user code

/**
 * @author MTL
 */
public class Pagamento {
    /**
     * the Valor attribute.
     */
    private EFloat Valor;
    /**
     * the Data attribute.
     */
    private EDate Data;
    /**
     * the NFat attribute.
     */
    private Integer NFat;
    /**
     * the Valor getter.
     * @return the Valor.
     */
    public EFloat getValor() {
        return this.Valor;
    }

    /**
     * the Valor setter.
     * @param p_Valor the Valor to set.
     */
    public void setValor(EFloat p_Valor) {
        this.Valor = p_Valor;
    }
    /**
     * the Data getter.
     * @return the Data.
     */
    public EDate getData() {
        return this.Data;
    }

    /**
     * the Data setter.
     * @param p_Data the Data to set.
     */
    public void setData(EDate p_Data) {
        this.Data = p_Data;
    }
    /**
     * the NFat getter.
     * @return the NFat.
     */
    public Integer getNFat() {
        return this.NFat;
    }

    /**
     * the NFat setter.
     * @param p_NFat the NFat to set.
     */
    public void setNFat(Integer p_NFat) {
        this.NFat = p_NFat;
    }
    /**
     * the src attribute.
     */
    private ContaInt src;
    /**
     * the dst attribute.
     */
    private Pagamento dst;
}
