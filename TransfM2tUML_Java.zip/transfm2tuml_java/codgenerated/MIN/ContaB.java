/**
 * Generated with MTL UML 2 Java example
 */
package MIN;

// Start of user code for imports
import java.util.*;
// End of user code

/**
 * @author MTL
 */
public class ContaB {
    /**
     * the N_ag attribute.
     */
    private Integer N_ag;
    /**
     * the N_conta attribute.
     */
    private Integer N_conta;
    /**
     * the N_ag getter.
     * @return the N_ag.
     */
    public Integer getN_ag() {
        return this.N_ag;
    }

    /**
     * the N_ag setter.
     * @param p_N_ag the N_ag to set.
     */
    public void setN_ag(Integer p_N_ag) {
        this.N_ag = p_N_ag;
    }
    /**
     * the N_conta getter.
     * @return the N_conta.
     */
    public Integer getN_conta() {
        return this.N_conta;
    }

    /**
     * the N_conta setter.
     * @param p_N_conta the N_conta to set.
     */
    public void setN_conta(Integer p_N_conta) {
        this.N_conta = p_N_conta;
    }
    /**
     * the dst attribute.
     */
    private ContaB dst;
    /**
     * the dst attribute.
     */
    private ContaInt dst;
    /**
     * the src attribute.
     */
    private Cliente src;
    /**
     * the src attribute.
     */
    private ContaB src;
}
